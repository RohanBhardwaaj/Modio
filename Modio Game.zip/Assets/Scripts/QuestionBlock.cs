﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestionBlock : MonoBehaviour
{
    public GameObject qb;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject.Find("Player").GetComponent<Movement>().playboxsound();
        GameObject.Find("Player").GetComponent<Movement>().score += 20;
        Destroy(qb);
    }
}
