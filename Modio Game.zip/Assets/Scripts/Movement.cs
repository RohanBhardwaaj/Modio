﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour
{
    public float playerspeed;
    public float jumpspeed;
    public int score;
    public Text scoretext;
    public AudioClip audioClip;
    public AudioClip audioClip2;
    public AudioClip audioClip3; 
    
    private bool isjumping;
    private float move;
    private Rigidbody2D rb;
    private Animator ani;
    private AudioSource audioSource;
    

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        ani = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        score = 0;
    }

    void Update()
    {
        scoretext.text = "Score : " + score;

        move = Input.GetAxis("Horizontal");

    
        if (move < 0)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);

        }

        else if (move > 0)
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
        }

        if (move != 0 && isjumping == true)
        {
            ani.SetBool("isRunning", true);
        }

        else
        {
            ani.SetBool("isRunning", false);
        }

        rb.velocity = new Vector2(move * playerspeed, rb.velocity.y);

        if (Input.GetKeyDown(KeyCode.Space) && isjumping == true)
        {
            rb.velocity = new Vector2(rb.velocity.x , jumpspeed);
            ani.SetBool("isJumping", true);
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("GroundLong"))
        {
            ani.SetBool("isJumping", false);
        }
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("GroundLong"))
        {
            isjumping = true;
        }

        if (collision.gameObject.tag == "Enemy")
        {
            
            Destroy(gameObject);            
            SceneManager.LoadScene("Lose");            
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {

        if (collision.gameObject.CompareTag("GroundLong"))
        {
            isjumping = false;
        }
    }

    public void playcoinsound()
    {
        audioSource.PlayOneShot(audioClip);
    }

    public void playboxsound()
    {
        audioSource.PlayOneShot(audioClip2);
    }

    public void playkillsound()
    {
        audioSource.PlayOneShot(audioClip3);
    }

}
