﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public GameObject en;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            GameObject.Find("Player").GetComponent<Movement>().playkillsound();
            GameObject.Find("Player").GetComponent <Movement>().score += 10;
            Destroy(en);
        }
    }
}
